const examForm = document.getElementById('exam-form');
const questionContainers = document.querySelectorAll('.question-container');
const submitBtn = document.getElementById('submit-btn');
const resultContainer = document.getElementById('result-container');
const scoreElement = document.getElementById('score');
const reviewBtn = document.getElementById('review-btn');

let answers = {};
let markedQuestions = [];
let currentQuestionIndex = 0;

examForm.addEventListener('submit', (e) => {
    e.preventDefault();
    calculateScore();
});

questionContainers.forEach((questionContainer, index) => {
    const radioButtons = questionContainer.querySelectorAll('input[type="radio"]');
    const skipBtn = questionContainer.querySelector('.skip-btn');
    const markBtn = questionContainer.querySelector('.mark-btn');
    const reviewIcon = questionContainer.querySelector('.review-icon');

    radioButtons.forEach((radioButton) => {
        radioButton.addEventListener('click', () => {
            const questionId = radioButton.name;
            answers[questionId] = radioButton.value;
        });
    });

    skipBtn.addEventListener('click', () => {
        currentQuestionIndex++;
        if (currentQuestionIndex < questionContainers.length) {
            questionContainers[currentQuestionIndex - 1].style.display = 'none';
            questionContainers[currentQuestionIndex].style.display = 'block';
        }
    });

    markBtn.addEventListener('click', () => {
        const questionId = markBtn.parentNode.querySelector('input[type="radio"]').name;
        markedQuestions.push(questionId);
        reviewIcon.style.display = 'block';
    });
});

submitBtn.addEventListener('click', () => {
    calculateScore();
});

reviewBtn.addEventListener('click', () => {
    resultContainer.style.display = 'none';
    questionContainers.forEach((questionContainer) => {
        questionContainer.style.display = 'block';
        const radioButtons = questionContainer.querySelectorAll('input[type="radio"]');
        radioButtons.forEach((radioButton) => {
            radioButton.disabled = true;
        });
    });
    markedQuestions.forEach((questionId) => {
        const questionContainer = document.querySelector(`[data-question-id="${questionId}"]`);
        questionContainer.querySelector('.review-icon').style.display = 'block';
    });
});

function calculateScore() {
    let score = 0;
 Object.keys(answers).forEach((questionId) => {
        if (answers[questionId] === 'A') {
            score++;
        }
    });
    scoreElement.textContent = `You scored ${score} out of 10`;
    resultContainer.style.display = 'block';
    questionContainers.forEach((questionContainer) => {
        questionContainer.style.display = 'none';
    });
}   